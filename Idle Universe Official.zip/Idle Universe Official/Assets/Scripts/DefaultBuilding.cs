﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.UI.Extensions;
using TMPro;
using System;

public class DefaultBuilding : MonoBehaviour
{

    CurrencyManager Manager;
    public Canvas RootCanvas;

    public string buildingName = "Default Building Name";
    public float productionValue = 0.1f;
    public float unlockCost = 0;
    public float upgradeProductionCost = 2.5f;
    public float baseProductionCost;
    public float productionLevel = 1;
    public float upgradeIdleSpeedCost = 25f;
    public float baseSpeedCost;
    public float idleSpeedLevel = 1;
    public float idleTime = 1f;
    public float totalIdleTime;
    public TextMeshProUGUI IdleSpeedUpgradeCost;
    public TextMeshProUGUI ProductionUpgradeCost;
    public Animation Anim;
    public Slider Slider;
    public TextMeshProUGUI SliderPercent;

    public Button UpgradeProductionButton;
    public Button UpgradeSpeedButton;
    public Slider ProgressBar;
    public Button ClickableButton;

    // Start is called before the first frame update
    void Start()
    {
        RootCanvas = GetComponentInParent<Canvas>();

        Manager = Camera.main.GetComponent<CurrencyManager>();
        StartCoroutine(IdleGen());
        totalIdleTime = idleTime;
        baseProductionCost = upgradeProductionCost;
        baseSpeedCost = upgradeIdleSpeedCost;

        AddPassiveCurrency();

    }

    // Update is called once per frame
    void Update()
    {
        IdleSpeedUpgradeCost.text = upgradeIdleSpeedCost.ToString();
        ProductionUpgradeCost.text = upgradeProductionCost.ToString();
        idleTime -= Time.deltaTime;
        Slider.value = idleTime;
        SliderPercent.text = (System.Math.Round(Slider.value, 2) * 100).ToString() + "% | " + System.Math.Round(idleTime, 2);

    }

    IEnumerator IdleGen()
    {
        while (true && idleTime >= 0)
        {
            yield return new WaitForSeconds(idleTime);
            Manager.Credits += productionValue / 2;
            Anim.Play("TapAnimation");
            idleTime = totalIdleTime;
        }
    }

    public void UpgradeProduction()
    {
        if (Manager.Credits >= upgradeProductionCost)
        {
            Manager.Credits -= upgradeProductionCost;
            productionValue = (productionValue * 1.05f);
            upgradeProductionCost = (float)System.Math.Round(baseProductionCost * Mathf.Pow(1.10f, productionLevel), 2);
            productionLevel++;
        }
    }

    public void UpgradeSpeed()
    {
        if (Manager.Credits >= upgradeIdleSpeedCost)
        {
            Manager.Credits -= upgradeIdleSpeedCost;
            idleTime = (totalIdleTime * 0.95f);
            upgradeIdleSpeedCost = (float)System.Math.Round(baseSpeedCost * Mathf.Pow(1.10f, idleSpeedLevel), 2);
            Slider.minValue = 0;
            Slider.maxValue = idleTime;
            totalIdleTime = idleTime;
            idleSpeedLevel++;
        }
    }

    public void TapBuilding()
    {
        Manager.Credits += productionValue;
        Anim.Play("TapAnimation");
    }

    public void AddPassiveCurrency()
    {
        //Manager.Credits += ((float)secondsPassed / totalIdleTime) * productionValue/2;
    }
}
