﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[Serializable]
public class CurrencyData
{
    public float CreditsToLoad;
    public long LastLogIn;

    public CurrencyData(CurrencyManager CM)
    {
        CreditsToLoad = CM.Credits;
        LastLogIn = System.DateTime.Now.Ticks;
    }

}
