﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI.Extensions;

public class InstantiateBuildings : MonoBehaviour
{
    public GameObject NewPrefab;
    public GameObject Parent;

    public void SpawnNew()
    {
        GameObject Container = Instantiate(NewPrefab, Parent.transform);
        gameObject.GetComponent<HorizontalScrollSnap>().UpdateLayout();
        Container.GetComponent<RectTransform>().localPosition = new Vector3(Container.transform.position.x, Container.transform.position.y - 50, 0);
    }

    public void SpawnFirst()
    {
        GameObject Container = Instantiate(NewPrefab, Parent.transform);
        gameObject.GetComponent<HorizontalScrollSnap>().UpdateLayout();
    }

    private void Start()
    {
        SpawnFirst();
    }
}
