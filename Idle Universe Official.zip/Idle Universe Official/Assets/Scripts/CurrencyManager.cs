﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System;

[Serializable]
public class CurrencyManager : MonoBehaviour
{
    public TextMeshProUGUI CreditText;
    public float Credits;

    public float CurrentCredits;
    public float NewCredits;

    public float CreditsPSec;
    public TextMeshProUGUI CreditsPSecText;


    // Start is called before the first frame update
    void Start()
    {
        InvokeRepeating("GetCurrentCredits", 0, 1);
        InvokeRepeating("GetNewCredits", 1, 1);
        LoadData();
    }

    // Update is called once per frame
    void Update()
    {
        CreditText.text = System.Math.Round(Credits, 2).ToString();
        CreditsPSecText.text = System.Math.Round(CreditsPSec, 2).ToString() + "/s";
    }

    public void SaveData()
    {
        SaveSystem.SaveCurrency(this);
    }

    public void LoadData()
    {
        CurrencyData data = SaveSystem.LoadCurrency();

        Credits = data.CreditsToLoad;
    }

    void GetCurrentCredits()
    {
        CurrentCredits = Credits;
    }

    void GetNewCredits()
    {
        NewCredits = Credits;
        CreditsPSec = (NewCredits - CurrentCredits);        
        CreditsPSecText.text = System.Math.Round(CreditsPSec, 2).ToString() + "/s";
    }

    private void OnApplicationQuit()
    {
        SaveData();
    }

}
