﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

public static class SaveSystem
{
    public static void SaveCurrency (CurrencyManager currency)
    {
        BinaryFormatter formatter = new BinaryFormatter();
        string path = Application.persistentDataPath + "/CurrencyData.dat";
        FileStream stream = new FileStream(path, FileMode.Create);

        CurrencyData data = new CurrencyData(currency);

        formatter.Serialize(stream, data);
        stream.Close();
    }

    public static CurrencyData LoadCurrency()
    {
        string path = Application.persistentDataPath + "/CurrencyData.dat";
        if (File.Exists(path))
        {
            BinaryFormatter formatter = new BinaryFormatter();
            FileStream stream = new FileStream(path, FileMode.Open);

            CurrencyData data = formatter.Deserialize(stream) as CurrencyData;
            stream.Close();

            return data;
        }
        else
        {
            Debug.Log("Path does not exsist");
            return null;
        }
    }
}
