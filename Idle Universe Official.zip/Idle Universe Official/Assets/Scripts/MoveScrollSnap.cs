﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;

public class MoveScrollSnap : MonoBehaviour
{
    public GameObject BuildingScrollSnap;
    bool IsInView;

    public List<GameObject> ScrollSnapList;

    public GameObject PosManager;
    // Start is called before the first frame update
    void Start()
    {
        MoveOutOfView(BuildingScrollSnap);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void ToggleView()
    {
        if (IsInView)
        {
            MoveOutOfView(BuildingScrollSnap);
        }
        else if (!IsInView)
        {
            MoveIntoView(BuildingScrollSnap);
        }
    }

    public void MoveOutOfView(GameObject ScrollSnap)
    {
        ScrollSnap.transform.DOMove(new Vector3(0, -1200, 800), 1).SetEase(Ease.InOutQuart);
    }

    public void MoveIntoView(GameObject ObjectToView)
    {
        PosManager.GetComponent<ShowSystemView>().LastPlanet = ObjectToView;
        ObjectToView.transform.DOMove(new Vector3(0,1.6f,90), 1).SetEase(Ease.InOutQuart);
        for (int i = 0; i < ScrollSnapList.Count; i++)
        {
            GameObject ScrollSnap = ScrollSnapList[i].gameObject;
            ScrollSnap.transform.DOMove(new Vector3(0, -1200, 800), 1).SetEase(Ease.InOutQuart);
        }
    }
}
