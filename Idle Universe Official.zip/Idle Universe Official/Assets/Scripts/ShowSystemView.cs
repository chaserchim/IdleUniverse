﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;

public class ShowSystemView : MonoBehaviour
{
    public GameObject SystemObject;
    Vector3 defaultTransform;
    bool IsSystemInView = true;
    public List<GameObject> button;
    public List<GameObject> ScrollSnapList;

    public GameObject LastPlanet;

    private void Start()
    {
        defaultTransform = SystemObject.transform.position;
        SystemObject.transform.position = new Vector3(0, 0, 75);
    }

    public void SlideSystemIntoView()
    {
        if (!IsSystemInView)
        {
            SystemObject.transform.DOMove(new Vector3(0, 0, 75), 1).SetEase(Ease.InOutQuad);
            IsSystemInView = true;
            for (int i = 0; i < ScrollSnapList.Count; i++)
            {
                GameObject ScrollSnap = ScrollSnapList[i].gameObject;
                ScrollSnap.transform.DOMove(new Vector3(0, -1200, 800), 1).SetEase(Ease.InOutQuart);
            }
            for (int i = 0; i < button.Count; i++)
            {
                button[i].SetActive(false);
            }


        }
        else if (IsSystemInView)
        {
            SystemObject.transform.DOMove(new Vector3(defaultTransform.x, defaultTransform.y, -800), 1).SetEase(Ease.InOutQuad);
            IsSystemInView = false;
            for (int i = 0; i < button.Count; i++)
            {
                button[i].SetActive(true);
            }

        }
    }
}
