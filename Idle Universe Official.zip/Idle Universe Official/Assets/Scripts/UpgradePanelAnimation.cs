﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;

public class UpgradePanelAnimation : MonoBehaviour
{
    public bool IsEnabled = false;

    public void Toggle()
    {
        if (IsEnabled)
        {
            transform.DOMoveY(transform.position.y-30, 1);
            IsEnabled = false;
        }
        else if (!IsEnabled)
        {
            transform.DOMoveY(transform.position.y+30, 1);
            IsEnabled = true;
        }
    }
}
